/*
*Name: Junhao Wang, Colin Vandenhof, Teshaun Murray
*MacID: wangjh2, vandencm, murrayts
*Student Number: 1215428, 1231644, 1227515
*Description: main method that instantiates a UserInterface object to run the program
*/

public class HWK4_vandencm {

	public static void main(String[] args) { //main method
		UserInterface run = new UserInterface(); //instantiate UserInterface object

	}

}
